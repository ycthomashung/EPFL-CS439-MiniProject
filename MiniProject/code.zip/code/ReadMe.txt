CS-439 Optimization for machine learning mini-project
Name: Yui Chi HUNG
SCIPER: 319733

Guidelines:
The file "data" contains the data to be used, and the Jupyter notebook "BCEloss_smooth.ipynb" contains the complete executable and the graphs used in the final report.